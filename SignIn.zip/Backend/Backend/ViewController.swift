//
//  ViewController.swift
//  Backend
//
//  Created by BP-36-201-18 on 13/12/2025.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!

    @IBAction func loginButtonTapped(_ sender: UIButton) {

        let username = usernameTextField.text ?? ""
        let password = passwordTextField.text ?? ""

        if username == "admin" && password == "1234" {
            showAlert(title: "Success", message: "You are logged in!")
        } else {
            showAlert(title: "Error", message: "Invalid username or password.")
        }
    }

    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
